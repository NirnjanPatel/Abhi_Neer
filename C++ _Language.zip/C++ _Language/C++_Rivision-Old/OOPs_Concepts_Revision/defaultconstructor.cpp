// Default Constructor
#include <iostream>
using namespace std;
class Constructor
{
public:
    Constructor()
    {
        cout << "Default Constructor Called.....!!!!" << endl;
    }
};
int main()
{
    Constructor obj;
    return 0;
}