// Control statements // if statement
#include <iostream>
using namespace std;
int main()
{
    if (0 / 5)
    {
        cout << "s1" << endl;
    }
    else
    {
        if (-5)
        {
            cout << "s2" << endl;
        }
        else
        {
            if ("a")
            {
                cout << "s3" << endl;
            }
            else
            {
                if ("0")
                {
                    cout << "s4" << endl;
                }
            }
        }
    }
}