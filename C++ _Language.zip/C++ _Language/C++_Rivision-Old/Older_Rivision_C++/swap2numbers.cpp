// Swap two numbers
#include <iostream>
using namespace std;
int main()
{
}