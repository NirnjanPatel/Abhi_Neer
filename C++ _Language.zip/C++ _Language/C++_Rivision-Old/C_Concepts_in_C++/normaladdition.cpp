#include<iostream>
using namespace std;
int main()
{
    int a ,b;
    cout << "Enter Values of a & b : ";
    cin >> a >> b;
    cout << "Addition = "<<a+b<<endl;
    return 0;
}