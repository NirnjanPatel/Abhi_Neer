// Use of bool data type
#include<iostream>
using namespace std;
int main()
{
 bool choice=true;
 cout << "choice = " << choice << endl;
 bool neer = false;
 cout << "neer = " << neer << endl;
 return 0;
}