// Array of string
#include<iostream>
using namespace std;
int main()
{
char name[34];
cout<<"Enter your name : ";
cin.getline(name,34);
// getline don't need any library(header file)
return 0;
}