// Static data member and static member function
#include <iostream>
using namespace std;
class Student
{
private:
public:
};
int main()
{
}