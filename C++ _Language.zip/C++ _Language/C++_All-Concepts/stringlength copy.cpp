#include <iostream>
#include <string.h>
using namespace std;
int main()
{
    char getUpperCase[] = {45, 345, 54, 35, 35, 53};
    int len;
    len = strlen(getUpperCase);
    cout << "Length of string = " << len << endl;
}