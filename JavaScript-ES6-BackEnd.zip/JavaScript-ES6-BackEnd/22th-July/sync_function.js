//Synchronous function

console.log("Before function execution");

function demo() {
    console.log("Demo function invoked");
}

demo();

console.log("After function execution");
