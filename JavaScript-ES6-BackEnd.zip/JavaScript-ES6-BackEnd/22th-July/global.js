//global parameters : 

console.log("current working directory :", __dirname);

console.log("current working file :", __filename);

