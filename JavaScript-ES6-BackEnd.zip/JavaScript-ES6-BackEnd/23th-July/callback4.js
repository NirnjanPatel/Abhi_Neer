/*
function x(p1,p2,p3,cb)
{
 staments
 cb(r1,r2,r3) 
}

x(p1,p2,p3,(r1,r2,r3)=>{
 statements
})
*/
