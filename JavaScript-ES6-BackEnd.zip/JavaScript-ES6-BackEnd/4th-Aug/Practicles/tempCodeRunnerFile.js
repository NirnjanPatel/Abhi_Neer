    else if (req.url == '/contact') {
        res.write(req.url);
        res.write("<h1>This is contact page </h1>");
    }