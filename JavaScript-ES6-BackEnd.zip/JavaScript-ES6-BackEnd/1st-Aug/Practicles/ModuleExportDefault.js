// Module Export Default
// export var a = 100;

var a;
a = 100;
export default a;
