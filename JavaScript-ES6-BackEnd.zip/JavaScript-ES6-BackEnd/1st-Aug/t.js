var p = console.log("Module imported successfully....");
console.log("a = " + p);
