var a;
a = 100;
console.log("a = " + a);
export default a;