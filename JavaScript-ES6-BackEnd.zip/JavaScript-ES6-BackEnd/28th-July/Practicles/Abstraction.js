// re-initialisation of a class member outside a class is a fault of encapsulation
// to solve this we use Abstraction
