// import { useState } from "react";

// export default function state() {
//   const [data, setData] = useState("Patel");

//   setData("Malviya");
//   return (
//     <div>
//       Data : <h2>{data}</h2>
//       <button onClick={state}>Update Data</button>
//     </div>
//   );
// }
