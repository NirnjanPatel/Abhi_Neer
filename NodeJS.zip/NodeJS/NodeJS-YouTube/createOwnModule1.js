// Creating module
const add = (a, b) => {
    var c = a + b;
    return c;
}

const sub = (x, y) => {
    var z = x - y;
    return z;
}

const mult = (r, s) => {
    var t = r + s;
    return t;
}