var a;
a=100;
export default a;