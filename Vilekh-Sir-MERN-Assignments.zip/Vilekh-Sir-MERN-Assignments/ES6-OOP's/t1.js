import a from './m1.js';
import { b } from './m1.js'; 

console.log("Module imported successfully....");
console.log("a = "+a);
console.log("b = "+b);
