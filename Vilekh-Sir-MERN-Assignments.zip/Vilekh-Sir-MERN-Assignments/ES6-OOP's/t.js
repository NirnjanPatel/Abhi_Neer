import p from './m.js';
console.log("Module imported successfully....");
console.log("a = "+p);
