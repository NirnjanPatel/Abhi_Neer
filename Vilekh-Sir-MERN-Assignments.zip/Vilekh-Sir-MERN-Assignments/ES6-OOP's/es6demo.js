var a;
a=100;
console.log("Welcome to world of ES6");
console.log("a = "+a);
