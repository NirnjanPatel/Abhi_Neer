import a from './m2.js';
import { b , demo , demo1 } from './m2.js'; 

console.log("Module imported successfully....");
console.log("a = "+a);
console.log("b = "+b);

demo();
demo1();
